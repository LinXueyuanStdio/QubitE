# nn

This package contains classic knowledge graph embedding models.

## Symbols

The comments in the source code use these symbols:

```
T: number of triples
B: batch size
d: dimension
d_e: dimension of entity embedding
d_r: dimension of relation embedding
```
