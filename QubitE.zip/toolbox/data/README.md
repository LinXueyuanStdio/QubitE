
## TODO 
1. Maybe we can create data dir and hold some classic datasets to prevent downloading from the source to accelerate coding process.
