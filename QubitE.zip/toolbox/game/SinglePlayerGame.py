"""
@author: lxy
@email: linxy59@mail2.sysu.edu.cn
@date: 2021/9/26
@description: null
"""


class SinglePlayerGameEnv:
    def __init__(self):
        pass

    def reset(self):
        # return state
        pass

    def step(self, action):
        # return state, reward, done, info
        pass

    def state(self):
        # return state
        pass

    def render(self, show=False):
        pass
