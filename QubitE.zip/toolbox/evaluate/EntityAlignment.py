
def entity_alignment(predictions):
    """
    predictions : torch.Tensor, similarity matrix of shape (entity_count, entity_count)
    """
    pass