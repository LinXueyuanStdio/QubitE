__all__ = ["EntityAlignment", "LinkPredict", "Evaluate"]
